import torch
from PIL import Image
import os,sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Load the local_lung.pth model
model = torch.load('local_lung.pth', map_location=torch.device('cpu'))

image_path = r"C:\Users\Mehaboob\Downloads\x_ray_test_image.png"

import torchvision.transforms as transforms

# Load and preprocess image
image = Image.open(image_path).convert('RGB')
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
image_tensor = transform(image).unsqueeze(0)

# Make prediction
model.eval()
with torch.no_grad():
    output = model(image_tensor)
    prediction = output.argmax(dim=1)

print(f"Prediction: {prediction.item()}")