import torch
import torch.nn as nn
import torch.nn.functional as F
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvLayer(nn.Sequential):
    def __init__(self, in_ch, out_ch, kernel=3, stride=1):
        super().__init__()
        padding = kernel // 2
        self.add_module("conv", nn.Conv2d(in_ch, out_ch, kernel, stride, padding))
        self.add_module("bn", nn.BatchNorm2d(out_ch))
        self.add_module("relu", nn.ReLU(inplace=True))


class DWConvLayer(nn.Sequential):
    def __init__(self, ch, stride=1):
        super().__init__()
        self.add_module("dw", nn.Conv2d(ch, ch, 3, stride, 1, groups=ch))
        self.add_module("bn", nn.BatchNorm2d(ch))
        self.add_module("relu", nn.ReLU(inplace=True))


class HarDBlock(nn.Module):
    def get_link(self, layer, base_ch, growth_rate, grmul):
        if layer == 0:
            return base_ch, 0, []

        out_channels = growth_rate
        link = []

        for i in range(10):
            dv = 2 ** i
            if layer % dv == 0:
                link.append(layer - dv)
                if i > 0:
                    out_channels *= grmul

        # make it even
        out_channels = int(out_channels // 2) * 2

        in_channels = 0
        for l in link:
            ch, _, _ = self.get_link(l, base_ch, growth_rate, grmul)
            in_channels += ch

        return out_channels, in_channels, link

    def __init__(self, in_channels, growth_rate, grmul, n_layers):
        super().__init__()
        self.links = []
        layers = []
        base_ch = in_channels

        for i in range(n_layers):
            out_ch, in_ch, link = self.get_link(i + 1, base_ch, growth_rate, grmul)
            self.links.append(link)
            layers.append(ConvLayer(in_ch, out_ch))

        self.layers = nn.ModuleList(layers)

        # compute total output channels following concatenation rule
        self.out_channels = in_channels
        for i in range(n_layers):
            if (i == n_layers - 1) or ((i + 1) % 2 == 1):
                ch, _, _ = self.get_link(i + 1, base_ch, growth_rate, grmul)
                self.out_channels += ch

    def forward(self, x):
        feats = [x]

        for i, layer in enumerate(self.layers):
            link = self.links[i]
            inputs = [feats[idx] for idx in link]
            x_in = torch.cat(inputs, 1) if len(inputs) > 1 else inputs[0]
            out = layer(x_in)
            feats.append(out)

        outputs = []
        for i in range(len(feats)):
            if i == 0 or i == len(feats) - 1 or i % 2 == 1:
                outputs.append(feats[i])

        return torch.cat(outputs, 1)


class HarDNet68Encoder(nn.Module):
    def __init__(self):
        super().__init__()

        # HarDNet68 config
        first_ch = [32, 64]
        gr       = [14,16,20,40,160]
        n_layers = [8,16,16,16,4]
        grmul    = 1.7
        downSamp = [1,0,1,1,0]
        ch_list  = [128,256,320,640,1024]

        self.layers = nn.ModuleList()
        self.stage_id = []

        # stem
        self.layers.append(ConvLayer(3, first_ch[0], 3, 2))       # 0
        self.layers.append(ConvLayer(first_ch[0], first_ch[1], 1))# 1
        self.layers.append(nn.MaxPool2d(3, 2, 1))                 # 2

        ch = first_ch[1]

        for i in range(5):
            blk = HarDBlock(ch, gr[i], grmul, n_layers[i])
            self.layers.append(blk)                               # 3,5,7,9,11
            conv = ConvLayer(blk.out_channels, ch_list[i], 1)
            self.layers.append(conv)                              # 4,6,8,10,12
            ch = ch_list[i]
            self.stage_id.append(len(self.layers) - 1)            # record stage outputs

            if downSamp[i] == 1:
                self.layers.append(nn.MaxPool2d(2, 2))            # optional downsampling

    def forward(self, x):
        feats = []
        for idx, layer in enumerate(self.layers):
            x = layer(x)
            if idx in self.stage_id:
                feats.append(x)
        # feats = [f1, f2, f3, f4, f5]
        return feats

# ---------- Channel Attention ----------
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction, in_channels, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * self.sigmoid(y)

# ---------- Spatial Attention ----------
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        y = torch.cat([avg_out, max_out], dim=1)
        y = self.conv(y)
        return x * self.sigmoid(y)

# ---------- Combined Spatial + Channel Attention (SCA) ----------
class SCA(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.ca = ChannelAttention(in_channels)
        self.sa = SpatialAttention()

    def forward(self, x):
        x = self.ca(x)
        x = self.sa(x)
        return x

class ASPPBlock(nn.Module):
    """One Atrous Spatial Pyramid block"""
    def __init__(self, in_channels, out_channels, dilation):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=dilation, dilation=dilation),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
    def forward(self, x):
        return self.conv(x)

class DenseASPP(nn.Module):
    """
    DenseASPP: multi-scale dilated convolution pyramid
    commonly used in polyp segmentation.
    """
    def __init__(self, in_channels, growth_rate=64, dilations=[3, 6, 12, 18]):
        super().__init__()
        self.blocks = nn.ModuleList()
        self.out_channels = in_channels

        current_channels = in_channels
        for d in dilations:
            self.blocks.append(ASPPBlock(current_channels, growth_rate, dilation=d))
            current_channels += growth_rate  # dense concatenation

        self.out_channels = current_channels

    def forward(self, x):
        features = [x]
        current = x
        for block in self.blocks:
            out = block(current)
            features.append(out)
            current = torch.cat([current, out], dim=1)
        return current  # concatenated output

class UpBlock(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch):
        super().__init__()
        self.conv1 = ConvLayer(in_ch + skip_ch, out_ch, 3)
        self.conv2 = ConvLayer(out_ch, out_ch, 3)
        self.sca = SCA(out_ch)   # ← ADD THIS

    def forward(self, x, skip):
        x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=False)
        x = torch.cat([x, skip], dim=1)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.sca(x)   # ← APPLY ATTENTION HERE
        return x

class HarDNetUNet(nn.Module):
    def __init__(self, embed_dim=128):
        super().__init__()
        self.encoder = HarDNet68Encoder()

        self.dense_aspp = DenseASPP(in_channels=1024)

        self.up4 = UpBlock(self.dense_aspp.out_channels, 640, 256)
        self.up3 = UpBlock(256, 320, 128)
        self.up2 = UpBlock(128, 256, 64)
        self.up1 = UpBlock(64, 128, 32)

        self.final = nn.Conv2d(32, 1, 1)

        # 🔥 Projection head (50176 → 128)
        self.proj = nn.Linear(224*224, embed_dim)

    def forward(self, x):
        H, W = x.shape[2], x.shape[3]

        f1, f2, f3, f4, f5 = self.encoder(x)
        f5_aspp = self.dense_aspp(f5)

        x = self.up4(f5_aspp, f4)
        x = self.up3(x, f3)
        x = self.up2(x, f2)
        x = self.up1(x, f1)

        mask = torch.sigmoid(self.final(x))
        mask = F.interpolate(mask, size=(H, W), mode="bilinear", align_corners=False)

        # 🔥 Flatten mask → [N, 50176]
        flat = mask.view(mask.size(0), -1)

        # 🔥 Project → [N, 128]
        embed = self.proj(flat)
        return embed
