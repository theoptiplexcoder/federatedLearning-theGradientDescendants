# client/run_client.py
import torch, os, json, sys
from pathlib import Path

# Make project root importable
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(PROJECT_ROOT)

# ---- Import Your Models ----
from client_logits import compute_logits_on_seeds, dp_clip_and_noise, save_client_logits_for_upload
from model_seg import HarDNetUNet
from model_cls import VisionTransformer

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


# ----------------------------------------------------------
# Build round-specific updates directory
# ----------------------------------------------------------
def get_out_dir(round_number: int):
    return os.path.join(PROJECT_ROOT, "server", f"updates_round{round_number}")


# ----------------------------------------------------------
# Load Local Model (segmentation or classification)
# ----------------------------------------------------------
def load_local_model(path, client_type="segmentation", num_classes=2):
    print(f"\n[CLIENT] Loading model from: {path}")
    print(f"[CLIENT] Client type: {client_type}")

    if not os.path.exists(path):
        raise FileNotFoundError(f"❌ Local model not found: {path}")

    if client_type == "segmentation":
        model = HarDNetUNet().to(DEVICE)

    elif client_type == "classification":
        model = VisionTransformer(
            img_size=224,
            patch_size=16,
            in_channels=3,
            num_classes=num_classes,
            embed_dim=128,
            depth=8,
            num_heads=4,
            mlp_dim=256,
            drop_rate=0.1
        ).to(DEVICE)

    else:
        raise ValueError("Invalid client_type. Must be segmentation/classification")

    # Load weights
    state = torch.load(path, map_location=DEVICE)
    try:
        model.load_state_dict(state, strict=False)
    except:
        print("[CLIENT] ⚠️ Warning: State dict not strict, loading best match only.")

    model.eval()
    print("[CLIENT] Model loaded successfully.\n")
    return model


# ----------------------------------------------------------
# Main Client FL Procedure
# ----------------------------------------------------------
def main(
    client_id="C1",
    client_type="segmentation",
    local_model_path=None,
    dp_clip=1.0,
    noise_multiplier=0.5,
    num_classes=2,
    round_number=1
):

    # Create round folder
    OUT_DIR = get_out_dir(round_number)
    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

    print(f"[CLIENT] Running Client {client_id} for ROUND {round_number}")
    print(f"[CLIENT] Model path   : {local_model_path}")
    print(f"[CLIENT] DP Clip      : {dp_clip}")
    print(f"[CLIENT] Noise Mult.  : {noise_multiplier}")

    # Load seed images
    seeds_file = os.path.join(PROJECT_ROOT, "server", "seeds_round1.json")
    with open(seeds_file, "r") as f:
        seeds = json.load(f)["seeds"]

    # Load model
    model = load_local_model(local_model_path, client_type, num_classes)

    # Compute logits on seeds
    print("[CLIENT] Computing logits on seeds...")
    logits = compute_logits_on_seeds(
        model, seeds, device=DEVICE, client_type=client_type
    )

    print("[CLIENT] Raw logits shape:", logits.shape)
    print("[CLIENT] Example raw logits:", logits[0])

    # Apply DP clipping + noise
    logits_dp = dp_clip_and_noise(
        logits.to(DEVICE),
        l2_clip=dp_clip,
        noise_multiplier=noise_multiplier
    )

    print("[CLIENT] Example DP logits:", logits_dp[0])

    # Save federated update for this round
    out_path = os.path.join(OUT_DIR, f"{client_id}_logits_round{round_number}.pth")
    save_client_logits_for_upload(
        client_id=client_id,
        logits_dp=logits_dp.cpu(),
        n_samples=len(seeds),
        out_path=out_path
    )

    print(f"[CLIENT] ✅ Saved update → {out_path}")
    print("[CLIENT] Client update complete.\n")


# ----------------------------------------------------------
# CLI Entry Point
# ----------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--client_id", default="C1")
    parser.add_argument("--client_type", default="segmentation")
    parser.add_argument("--local_model_path", default=None)
    parser.add_argument("--round", type=int, default=1)
    parser.add_argument("--dp_clip", type=float, default=1.0)
    parser.add_argument("--noise_multiplier", type=float, default=0.5)

    args = parser.parse_args()

    main(
        client_id=args.client_id,
        client_type=args.client_type,
        local_model_path=args.local_model_path,
        round_number=args.round,
        dp_clip=args.dp_clip,
        noise_multiplier=args.noise_multiplier
    )
