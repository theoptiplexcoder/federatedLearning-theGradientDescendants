import torch
import torch.nn as nn
import torch.nn.functional as F

class GlobalCNN(nn.Module):
    def __init__(self, out_dim=128):
        super().__init__()
        
        # Shared CNN Backbone (very lightweight)
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),  # 112x112
            nn.BatchNorm2d(32),
            nn.ReLU(),

            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1), # 56x56
            nn.BatchNorm2d(64),
            nn.ReLU(),

            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1), # 28x28
            nn.BatchNorm2d(128),
            nn.ReLU(),

            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1), # 14x14
            nn.BatchNorm2d(256),
            nn.ReLU(),

            nn.Conv2d(256, 512, kernel_size=3, stride=2, padding=1), # 7x7
            nn.BatchNorm2d(512),
            nn.ReLU(),
        )

        # Projection head → matches embedding dimension of 128
        self.fc = nn.Linear(512 * 7 * 7, out_dim)

    def forward(self, x):
        x = self.features(x)  # [B, 512, 7, 7]
        x = x.view(x.size(0), -1)
        x = self.fc(x)        # [B, 128]
        return x
