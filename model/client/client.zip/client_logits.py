# client/client_logits.py

import torch
import numpy as np
import os

SHARED_EMBED_DIM = 128  # Final dimensionality for FedMD aggregation


# ----------------------------------------------------------
# Convert seed list into a tensor
# ----------------------------------------------------------
def seeds_to_tensor(seeds):
    arr = np.array(seeds, dtype=np.float32)
    return torch.from_numpy(arr)  # [N, C, H, W]


# ----------------------------------------------------------
# Projection Head (applies to ANY model output)
# ----------------------------------------------------------
class ProjectionHead(torch.nn.Module):
    def __init__(self, in_dim, out_dim=SHARED_EMBED_DIM):
        super().__init__()
        self.linear = torch.nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.linear(x)


# ----------------------------------------------------------
# Compute logits on seeds (segmentation + classification)
# ----------------------------------------------------------
def compute_logits_on_seeds(model, seeds, device="cpu", client_type="classification"):
    model.to(device).eval()
    x = seeds_to_tensor(seeds).to(device)

    # --------------------- RAW MODEL OUTPUT ---------------------
    with torch.no_grad():
        raw = model(x)

    # Flatten segmentation masks
    if client_type == "segmentation":
        raw = raw.view(raw.size(0), -1)  # (N, 50176)

    # Classification model already shape (N, 2)
    raw = raw.float()

    print(f"[DEBUG] Raw model output shape = {raw.shape}")

    # --------------------- APPLY PROJECTION ----------------------
    in_dim = raw.shape[1]
    proj = ProjectionHead(in_dim=in_dim, out_dim=SHARED_EMBED_DIM).to(device)

    with torch.no_grad():
        embed = proj(raw)  # ALWAYS (N, 128)

    print(f"[DEBUG] Projected embedding shape = {embed.shape}")

    return embed.cpu()


# ----------------------------------------------------------
# Differential Privacy: L2 clipping + Gaussian noise
# ----------------------------------------------------------
def dp_clip_and_noise(logits, l2_clip=1.0, noise_multiplier=0.5):
    logits = logits.float()

    norms = torch.norm(logits, p=2, dim=1, keepdim=True)
    clip_factors = torch.clamp(norms / l2_clip, min=1.0)
    clipped_logits = logits / clip_factors

    noise = torch.randn_like(clipped_logits) * noise_multiplier
    noisy_logits = clipped_logits + noise
    return noisy_logits


# ----------------------------------------------------------
# Save federated update
# ----------------------------------------------------------
def save_client_logits_for_upload(client_id, logits_dp, n_samples, out_path):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    torch.save({
        "client_id": client_id,
        "logits": logits_dp,
        "n_samples": n_samples
    }, out_path)

    print(f"[CLIENT] Saved DP logits to {out_path}")
